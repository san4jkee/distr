require_relative 'ServiceParsers/base_log_parser'
require_relative 'ServiceParsers/delayed_operations_service_log_parser'
require_relative 'ServiceParsers/indexing_service_log_parser'
require_relative 'ServiceParsers/preview_service_log_parser'
require_relative 'ServiceParsers/preview_storage_log_parser'
require_relative 'ServiceParsers/sungeroserver_log_parser'
require_relative 'ServiceParsers/webserver_log_parser'
require_relative 'ServiceParsers/worker_log_parser'
require_relative 'ServiceParsers/workflow_block_log_parser'
require_relative 'ServiceParsers/workflow_process_log_parser'
require_relative 'ServiceParsers/webclient_log_parser'
require_relative 'ServiceParsers/sungeroclient_log_parser'
require_relative 'ServiceParsers/webagent_log_parser'

require_relative 'ServiceParsers/nomad_server_log_parser'

require_relative 'ServiceParsers/data_from_csv_parser'

require_relative 'settings'
require_relative 'utils'
require_relative 'json_parser'
require 'time'

# Удалить ненужные поля.
#  event - текущее созданное событие LogStash.
#  key - узел json.
def remove_fields(event)
  keys = event.to_hash.keys
  keys.each do |key|
    # Найти в поступившей от Filebeat исходной json поля с лишней информацией и удалить их.
    # Набор полей зависит от версии Filebeat. Текущие актуальны для версии 7.X.
    event.remove(key) if key.start_with?('beat', 'host', 'input', 'offset', 'tags', 'agent', 'ecs')
  end
end

# Отфильтровать событие LogStash.
#   event - текущее созданное событие LogStash.
def filter(event) # rubocop:disable Metrics/CyclomaticComplexity,  Metrics/PerceivedComplexity, Metrics/MethodLength
  begin
    remove_fields(event)
    event.set('createdTimestamp', Time.now)
    result = []
    # Разобрать имя лог-файла. С версии Filebeat 7.X путь до лога приходит в другом поле, установить нужное.
    event.set('source', event.get('[log][file][path]'))

    # TODO: Убрать лишние поля в json (сейчас убрать не можем, т.к. жёстко прицеплены в event.rb к этому полю)
    # event.remove('[log][file][path]')

    # На линуксвой тачке неверно работает с путями windows, делаем преобразование.
    source_string = event.get('source').tr('\\', '/')

    # Вычисляем имя файла и имя папки, в которой он лежит
    log_file_name = File.basename(source_string)
    log_folder_name = File.dirname(source_string.tr('\\', '/')).split('/')
    log_folder_name = log_folder_name[log_folder_name.length - 1]

    # Для парсинга штучных логов проверяем, заполнено ли поле fields.rx_server
    event.set('[fields][rx_server]', log_folder_name) if event.get('[fields][rx_server]').nil?

    # Разобрать логи номада
    if log_file_name =~ /server(\..*)?\..*\.log$/
      result = NomadServerLogParser.new(event).parse_log
    # Разобрать сервисные логи
    elsif log_file_name =~ /(?<host>.*?)\.(?<service_name>.*)\.\d{4}-\d{2}-\d{2}\.log$/
      host = Regexp.last_match[:host]
      service_name = Regexp.last_match[:service_name]
      # Смена формата IP адреса с 192-168-0-1 на 192.168.0.1
      host = host.tr('-', '.') if host =~ /\d+\-\d+\-\d+\-\d+/
      # Убираем неинформативные элементы
      # Когда они будут убраны из названия логов - удалить доп. обработку
      service_name = service_name.sub('.Host', '')
      service_name = service_name.sub('Sungero.', '')
      service_name = Regexp.last_match[:serviceName].to_s.strip if service_name =~ /(?<serviceName>.*?)\..*/

      # В клиентских логах в 3.6 вместо SungeroClient теперь пишется DirectumRX. Для совместимости заменим на старое значение.
      if service_name.downcase == 'directumrx'
        service_name = 'SungeroClient'
      end
        
      service_name_downcase = service_name.downcase
      event.set('host', host)
      event.set('serviceName', service_name)
      event.set('[@metadata][serviceName]', service_name_downcase)
    # Разобрать данные в формате csv
    elsif log_file_name =~ /\.csv$/
      service_name = 'DataFromCSV'
      service_name_downcase = service_name.downcase
      event.set('serviceName', service_name)
      event.set('[@metadata][serviceName]', service_name_downcase)
    end
    Settings.instance.set_real_source(event)

    # Передать дальнейший парсинг специализированному парсеру или общему BaseLogParser.
    case service_name_downcase
    when 'cachemanager.w3wp'
      result = BaseLogParser.new(event).parse_log
    when 'client'
      result = BaseLogParser.new(event).parse_log
    when 'clientsconnectionservice'
      result = BaseLogParser.new(event).parse_log
    when 'delayedoperationsservice'
      result = BaseLogParser.new(event).parse_log
    when 'indexingservice'
      result = IndexingServiceLogParser.new(event).parse_log
    when 'previewservice'
      result = PreviewServiceLogParser.new(event).parse_log
    when 'previewstorage'
      result = PreviewStorageLogParser.new(event).parse_log
    when 'storageservice'
      result = BaseLogParser.new(event).parse_log
    when 'jobscheduler'
      result = BaseLogParser.new(event).parse_log
    when 'servicerunner'
      result = BaseLogParser.new(event).parse_log
    when 'w3wp'
      result = SungeroServerLogParser.new(event).parse_log
    when 'webserver'
      result = WebServerLogParser.new(event).parse_log
    when 'worker'
      result = WorkerLogParser.new(event).parse_log
    when 'workflowblockservice'
      result = WorkflowBlockLogParser.new(event).parse_log
    when 'workflowprocessservice'
      result = WorkflowProcessLogParser.new(event).parse_log
    when 'webclient'
      result = WebClientLogParser.new(event).parse_log
    when 'sungeroclient'
      result = SungeroClientLogParser.new(event).parse_log
    when 'webagent'
      result = WebAgentLogParser.new(event).parse_log
    when 'datafromcsv'
      result = DataFromCSVParser.new(event).detect_special_csv_files
    end

    JsonParser.detect_json_field(event)

    return result
  rescue StandardError => e
    raise $ERROR_INFO.exception(e.message + '
      {"source": "' + event.get('source') + '",
      "message": "' + event.get('message') + '"}')
  end
end
