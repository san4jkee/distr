# Настройки
require 'yaml'

# Класс определяющий тип ошибки.
class Settings
  CONFIG_FILE = 'settings.yml'.freeze

  def config
    @config ||= initialize_config
  end

  # Конструктор.
  def initialize_config
    config_full_path = File.join(File.dirname(__FILE__), CONFIG_FILE)
    return YAML.safe_load(File.read(config_full_path, encoding: 'utf-8')) if File.exist?(config_full_path)

    return YAML.safe_load('empty:')
  end

  # Одиночка.
  def self.instance
    return @@instance
  end
  @@instance = Settings.new # rubocop:disable Style/ClassVars
  private_class_method :new

  # Установить правильные слеши, в зависимости от префикса пути.
  #   path_new_prefix - новый префикс у пути
  #   path - полный путь с префиксом
  def set_right_slash(path_new_prefix, path)
    return path.tr('\\', '/') if !path_new_prefix.include?('\\')

    path = path.tr('/', '\\')
    # Добавить обратный слеш в начало пути для общей папки,
    # т.к. после замены префиксов вместо двойного слеша будет один
    return '\\' + path if path.start_with?('\\')
  end

  # Установить реальный source, потому что он может отличаться от того, что замаплено на виртуалке.
  #   event - текущее созданное событие LogStash.
  def set_real_source(event)
    return nil if config.nil?

    source_string = event.get('source')
    path_prefixes = 'path_prefixes'.freeze
    return nil if source_string.nil? || config[path_prefixes].nil?

    config[path_prefixes].each do |types|
      path_old_prefix = types['path_old_prefix']
      next if path_old_prefix.to_s.empty?

      next if !source_string.start_with?(path_old_prefix)

      path_new_prefix = types['path_new_prefix']
      source_string = source_string.gsub(path_old_prefix, path_new_prefix)
      source_string = set_right_slash(path_new_prefix, source_string)
      event.set('source', source_string)
      break
    end
  end
end
