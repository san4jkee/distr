require_relative 'utils'
require_relative 'generic_message_utils'
require 'time'
require 'ostruct'

KEY_INDEX = 0
VALUE_INDEX = 1

TYPE_OPERATION_INDEX = 0
ID_OPERATION_INDEX = 1

# Вернуть исходную строку если строка это число
#  value - исходная строка
def parse_number(value)
  return value if value =~ /\A[+-]?\d+?(\.\d+)?\Z/

  return nil
end

# Вернуть исходную строку если строка это дата
#  value - исходная строка
def parse_time(value)
  return value if value =~ /\A\d+:\d+:\d+.\d+\z/

  return nil
end

# Вернуть исходную строку если строка это гиперссылка
#  value - исходная строка
def parse_url(value)
  return value if value =~ /https?\:\/\/\S+/

  return nil
end

# Преобразовать строку: "ProjectDocuments.IApprovalAssignment:37256" в массив: [(str(IApprovalAssignment), int(37256))]
#   value - исходная строка, которую нужно преобразовать
def parse_entity(value)
  value_parts = value.split(':')
  if value_parts.count > 1
    value_struct = OpenStruct.new
    value_struct.type = parse_type_name(value_parts[TYPE_OPERATION_INDEX])
    value_struct.id = parse_number(value_parts[ID_OPERATION_INDEX])
    return value_struct
  end
  return nil
end

# Преобразовать строку: "CoreEntities.Client.FolderCollectionPresenter<Sungero.CoreEntities.IFolder>"
# в строку: "FolderCollectionPresenter<IFolder>"
#   value - исходная строка, которую нужно преобразовать
def parse_type_name(value)
  return nil if nil_or_empty?(value)

  if value =~ /(?<type>[^<]+)(<(?<generic_type>.*)>$)?/
    type_name = Regexp.last_match[:type]
    generic_type = Regexp.last_match[:generic_type]

    type_parts = type_name.split('.')
    type_name = type_parts.last if type_parts.count > 1
    type_name = format('%s<%s>', type_name, parse_type_name(generic_type)) if !nil_or_empty?(generic_type) # rubocop:disable Style/FormatStringToken, Metrics/LineLength
    return type_name
  end
  return nil
end

# Преобразование строки по шаблонам:
# ProjectDocuments.IApprovalAssignment:37256 -> [str(IApprovalAssignment), int(37256)]
# IFolder:4880 -> [str(IFolder), int(4880)]
# Planning.IPlan -> str(IPlan)
# Inbox -> str(Inbox)
# 37888 -> int(37888)
#   value - исходная строка, которую нужно преобразовать
def value_parse(value)
  return parse_url(value) ||
         parse_time(value) ||
         parse_number(value) ||
         parse_entity(value) ||
         parse_type_name(value)
end

# Установить значение параметров в событие
#   event - текущие событие
#   key - имя параметра
#   value - значение(я) параметра
def set_param(event, key, value)
  # Изменить ключ если это операция
  modified_key = if key == 'operation'
                   key + 'Type'
                 else
                   key
                 end
  if !nil_or_empty?(value)
    # Проверить, что value это структура из типа операции и ИД операции
    if value.is_a?(OpenStruct)
      event.set(modified_key, value.type)
      event.set(key + 'Id', value.id)
    else
      event.set(modified_key, value)
    end
  else
    # Установить значение ключа
    event.set(modified_key, true)
  end
end

# Распарсить информацию о запросах к СП
#  params - строка с параметрами запроса, перечисленными через запятую
def parse_request(params)
  prefix = 'request'
  @event.set('infoType', prefix)
  parse_params(@event, params)

  # Переименовать свойство продолжительности операции (total --> duration)
  duration = @event.get("#{prefix}Total")
  if !duration.nil?
    @event.set('duration', duration.to_i)
    @event.remove("#{prefix}Total")
  end

  # Заполнить имя операции
  func_name = @event.get("#{prefix}Func")
  request_name = @event.get('requestName')
  if !func_name.nil?
    @event.set("#{prefix}Operation", "#{request_name}.#{func_name}")
  else
    @event.set("#{prefix}Operation", request_name)
  end
end
# Распарсить параметры операции
#  event - текущее созданное событие LogStash.
#  params - строка с параметрами операции, перечисленными через запятую
#  need_parse_operation (false) - признак необходимости парсить имя операции
# (имя операции является первым элементом params)

def parse_params(event, params, need_parse_operation = false) # rubocop:disable Metrics/CyclomaticComplexity, Metrics/PerceivedComplexity, Metrics/LineLength
  prefix = event.get('infoType')
  params_parts = params.split(',')
  params_parts.each do |param|
    param_parts = param.split('=', 2)
    next if param_parts.count < 1

    key = param_parts[KEY_INDEX].strip
    next if nil_or_empty?(key)

    # Добавить признак, что событие отменено или упало
    if %w[failed canceled].include?(key)
      bad_status = prepare_key_name('badStatus', prefix)
      event.set(bad_status, key)
      next
    end
    value = if param_parts.count == 1
              nil
            else
              value_parse(param_parts[VALUE_INDEX].strip)
            end
    # Распарсить операцию
    if need_parse_operation
      operation = prepare_key_name('operation', prefix)
      event.set(operation, remove_numbers(key))
      set_param(event, operation, value) if !nil_or_empty?(value)
      need_parse_operation = false
      next
    end
    key = prepare_key_name(key, prefix)
    set_param(event, key, value)
  end
end

# Преобразовать исходное название поля в корректное название поля для elasticsearch
#  key - исходное название поля
#  prefix ('') - префикс названия
def prepare_key_name(key, prefix)
  # Выполнить капитализацию для имени поля и убрать пробелы (Entity type id --> entityTypeId)
  key = key.gsub(/\A\w/, &:downcase)
  key = "#{prefix} #{key}".lstrip if !nil_or_empty?(prefix) && !key.start_with?(prefix)
  key = key.gsub(/ \w/, &:upcase)
  key = key.delete(' ')
  return key
end
