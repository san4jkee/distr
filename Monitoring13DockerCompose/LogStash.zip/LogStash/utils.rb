require_relative 'generic_message_utils'
require 'time'

LOAD_MODULE_DONE_OLD = 'Module \'Sungero.Domain.\' load done'.freeze
LOAD_MODULE_DONE = 'Module \'Sungero.Domain\' load done'.freeze

# Извлечь метку времени в отдельный атрибут события.
#   event - событие LogStash.
def extract_timestamp(event)
  current_message = event.get('message')
  date_time_part = current_message[0, 29]

  time = Time.strptime(date_time_part, '%Y-%m-%d %H:%M:%S.%L%z')
  logstash_timestamp = convert_to_logstash_time(time)

  event.set('@timestamp', logstash_timestamp)
  event.set('message', current_message.slice(30, current_message.length - 1))
end

# Сконвертировать дату в объект Logstash timestamp
#  date_time(Time) - исходная дата
def convert_to_logstash_time(date_time)
  begin
    # При тестировании нет этого класса.
    return LogStash::Timestamp.new(date_time)
  rescue StandardError
    return date_time
  end
end

# Добавить поле с обобщенным сообщением
#   event - событие LogStash.
#   field_name - имя поля
#   message_text - исходный текст сообщения
def set_generic_message(event, field_name, message_text)
  if !message_text.nil? && message_text != ''
    generic_text = make_generic_message(message_text)
    event.set(field_name, generic_text)
  end
end

# Проверить есть ли в строке запуск приложения.
#   event - событие LogStash.
def set_service_start_time(event)
  current_message = event.get('message')
  if current_message.include?(LOAD_MODULE_DONE) || current_message.include?(LOAD_MODULE_DONE_OLD)
    event.set('serviceStarted', event.get('@timestamp'))
  end
  if current_message =~ /\*+ .+ started \(ver. (?<version>[\d+\.]+)\) \*+/m
    event.set('serviceStarted', event.get('@timestamp'))
    event.set('@version', Regexp.last_match[:version])
  end
end

# Проверить является ли строка нулевой или пустой
#  source_string - исходная строка
def nil_or_empty?(source_string)
  return (source_string.nil? || source_string == '')
end

# Вытащить внутренний класс исключения из System.AggregateException.
#  event - событие LogStash.
def process_aggregate_exception(event)
  exception_class = event.get('exception')
  if exception_class == 'System.AggregateException'
    stack_trace = event.get('stackTrace')
    if !stack_trace.nil?
      stack_trace_parts = stack_trace.split(' ---> ')
      if stack_trace_parts.length > 1
        inner_exception_part = stack_trace_parts[1]
        if inner_exception_part =~ /(?<exception>.*?):(?<message>.+?)\n(?<stack_trace>.*)/m
          event.set('exception', Regexp.last_match[:exception].to_s.strip)
          event.set('message', Regexp.last_match[:message].to_s.strip)
        end
      end
    end
  end
end

# Извлечь из стека вызовов метод, в котором возникло исключение, в специальное поле.
#  event - событие LogStash.
def set_exception_method(event)
  stack_trace = event.get('stackTrace')
  if !stack_trace.nil?
    stack_trace_parts = stack_trace.split("\n")
    for stack_trace_part in stack_trace_parts
      if stack_trace_part =~ /\s*(at|в) (?<exception_method>.*)\(/
        exception_method = Regexp.last_match[:exception_method].to_s.strip
        event.set('exceptionMethod', exception_method)
        return
      end
    end
  end
end

# Преобразовать строку с пробелами в формат UpperCamelCase. По умолчанию первая буква заглавная.
# Пример работы: camelize('updated jobs count') => UpdatedJobsCount
# Режимы работы:
# 1. Без параметров (по умолчанию) - каждое слово с заглавной
# 2. :lower - первая буква строчная, каждое последующее слово с заглавной
def camelize(string, mode = :lower)
  string = string.strip unless string.nil?
  return string if nil_or_empty?(string)

  formatted_string = ''
  massive_nonformatted_words = string.split(' ')
  if massive_nonformatted_words.length > 1
    massive_nonformatted_words.each do |word|
      word = word[0].upcase + word[1..-1].downcase
      formatted_string += word
    end
  else
    formatted_string = massive_nonformatted_words.join
  end
  formatted_string[0] = formatted_string[0].downcase if mode == :lower
  formatted_string
end
