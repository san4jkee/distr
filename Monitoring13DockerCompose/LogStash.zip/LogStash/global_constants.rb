MESSAGE_FIELD = 'message'.freeze
JSON_PREFIX_DOWNCASE = 'json:'.freeze
