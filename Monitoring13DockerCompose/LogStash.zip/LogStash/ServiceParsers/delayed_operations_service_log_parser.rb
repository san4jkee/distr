require_relative '../utils'
require_relative '../log_level'
require_relative 'base_log_parser'

# Класс парсера логов DelayedOperationsService.
class DelayedOperationsServiceLogParser < BaseLogParser
  # Парсинг стандартными обработчиками
  # При появлении особых сообщений с нестандартной структурой - добавлять сюда.
end
