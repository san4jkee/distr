require 'json'
require_relative '../utils'
require_relative '../log_level'
require_relative 'base_log_parser'

# Класс парсера логов веб-клиента.
class WebClientLogParser < BaseLogParser
  # Константы типовых операций
  NAVIGATE_TO_OPERATION = 'Navigate to'.freeze
  private_constant :NAVIGATE_TO_OPERATION
  ACTIVATE_OPERATION = 'Activate to'.freeze
  private_constant :ACTIVATE_OPERATION
  EXECUTE_ACTION_OPERATION = 'Execute action'.freeze
  private_constant :EXECUTE_ACTION_OPERATION
  EXECUTE_COVER_ACTION_OPERATION = 'Execute cover action'.freeze
  private_constant :EXECUTE_COVER_ACTION_OPERATION
  LOAD_MODULES_METADATA_OPERATION = 'Load modules metadata'.freeze
  private_constant :LOAD_MODULES_METADATA_OPERATION
  UPDATE_MARKED_COUNTS_OPERATION = 'Update marked counts'.freeze
  private_constant :UPDATE_MARKED_COUNTS_OPERATION
  API_OPERATION = 'api'.freeze
  private_constant :API_OPERATION
  AGENT_CALL_OPERATION = 'Agent call'.freeze
  private_constant :AGENT_CALL_OPERATION

  # Добавить поля JSON-строки к событию LogStash.
  #   json_string - строка, содержащая JSON.
  #   field_prefix - префикс создаваемых полей.
  def add_json_fields_to_event(json_string, field_prefix)
    json_hash = JSON.parse(json_string)
    json_hash.each do |key, value|
      if key == 'entityFullName'
        new_value = value.split('.')
        # Sungero.Workflow.SimpleAssignment -> Sungero | Workflow | SimpleAssignment ->
        # -> moduleName : Sungero.Workflow
        # -> entityName : Workflow.SimpleAssignment
        @event.set(field_prefix + 'moduleName', new_value[0] + '.' + new_value[1])
        @event.set(field_prefix + 'entityName', new_value[1] + '.' + new_value[2])
      elsif key == 'actionName'
        new_value = json_hash['moduleName'].split('.')
        @event.set(field_prefix + 'entityName', new_value[1] + '.' + value)
      else
        @event.set(field_prefix + key, value)
      end
    end
  end

  # Распарсить операцию навигации.
  #   operation_description - строка с описанием операции.
  def parse_navigate_operation(operation_description)
    if operation_description.start_with?(NAVIGATE_TO_OPERATION)
      @event.set('operation', NAVIGATE_TO_OPERATION)
      if operation_description =~ /Navigate to (?<parameters>.*), started = .*/
        parameters = Regexp.last_match[:parameters]
        add_json_fields_to_event(parameters, 'navigate.')
      end
      return true
    end
    return false
  end

  # Распарсить операцию активации.
  #   operation_description - строка с описанием операции.
  def parse_activate_operation(operation_description)
    if operation_description.start_with?(ACTIVATE_OPERATION)
      @event.set('operation', ACTIVATE_OPERATION)
      if operation_description =~ /Activate to (?<parameters>.*), started = .*/
        parameters = Regexp.last_match[:parameters]
        add_json_fields_to_event(parameters, 'activate.')
      end
      return true
    end
    return false
  end

  # Распарсить операцию выполнения действия.
  #   operation_description - строка с описанием операции.
  def parse_execute_action_operation(operation_description)
    if operation_description.start_with?(EXECUTE_ACTION_OPERATION)
      @event.set('operation', EXECUTE_ACTION_OPERATION)
      if operation_description =~ /Execute action = (?<action_name>[\w\s]+).*/
        @event.set('actionName', Regexp.last_match[:action_name])
      end
      if operation_description =~ /.*, context = (?<action_context>\{.*?\}), .*/
        action_context = Regexp.last_match[:action_context]
        add_json_fields_to_event(action_context, 'action.')
      end
      if operation_description =~ /.*, selected entity = (?<selected_entity>\{.*?\}), .*/
        selected_entity = Regexp.last_match[:selected_entity]
        add_json_fields_to_event(selected_entity, 'selectedEntity.')
      end
      return true
    end
    return false
  end

  # Распарсить операцию выполнения действия обложки.
  #   operation_description - строка с описанием операции.
  def parse_execute_cover_action_operation(operation_description)
    if operation_description.start_with?(EXECUTE_COVER_ACTION_OPERATION)
      @event.set('operation', EXECUTE_COVER_ACTION_OPERATION)
      if operation_description =~ /Execute cover action (?<cover_action_parameters>.*?), .*/
        cover_action_parameters = Regexp.last_match[:cover_action_parameters]
        add_json_fields_to_event(cover_action_parameters, 'coverAction.')
      end
      return true
    end
    return false
  end

  # Распарсить операцию загрузки метаданных модулей.
  #   operation_description - строка с описанием операции.
  def parse_load_modules_metadata_operation(operation_description)
    if operation_description.start_with?(LOAD_MODULES_METADATA_OPERATION)
      @event.set('operation', LOAD_MODULES_METADATA_OPERATION)
      return true
    end
    return false
  end

  # Распарсить операцию "update marked counts".
  #   operation_description - строка с описанием операции.
  def parse_update_marked_counts_operation(operation_description)
    if operation_description.start_with?(UPDATE_MARKED_COUNTS_OPERATION)
      @event.set('operation', UPDATE_MARKED_COUNTS_OPERATION)
      return true
    end
    return false
  end

  # Распарсить операцию "вызов метода api".
  #   operation_description - строка с описанием операции.
  def parse_api_operation(operation_description)
    if operation_description.start_with?(API_OPERATION)
      @event.set('operation', API_OPERATION)
      if operation_description =~ /api\/(?<api_request>[\w\.\-]+).*/
        @event.set('apiRequest', Regexp.last_match[:api_request])
      end
      return true
    end
    return false
  end

  # Удалить версию агента из сообщения об ошибке.
  #   message_text - текст сообщения.
  def remove_agent_version_from_message(message_text)
    if message_text =~ /(?<agent_version>\d\.\d\.\d\.\d\d\d\d) .*/
      message_text = message_text.slice(11, message_text.length - 1)
      @event.set('agentVersion', Regexp.last_match[:agent_version])
    end
    if message_text =~ /\[(?<agent_version>\d\.\d\.\d\.\d\d\d\d)\].*/
      message_text = message_text.slice(12, message_text.length - 1)
      @event.set('agentVersion', Regexp.last_match[:agent_version])
    end
    return message_text
  end

  # Распарсить вызов метода агента в ошибках.
  #   message_text - текст сообщения.
  def parse_error_agent_call(message_text)
    if message_text =~ /AGENT:.*requestName: (?<method>\S*)/
      @event.set('operation', AGENT_CALL_OPERATION)
      @event.set('agentMethod', Regexp.last_match[:method])
    end
  end

  # Конструктор.
  #   event - текущее событие LogStash.
  def initialize(event)
    super
    @parse_operation_methods = [
      method(:parse_navigate_operation),
      method(:parse_activate_operation),
      method(:parse_execute_action_operation),
      method(:parse_execute_cover_action_operation),
      method(:parse_load_modules_metadata_operation),
      method(:parse_update_marked_counts_operation),
      method(:parse_api_operation)
    ]
  end

  # Раcпарсить префикс в строке на соответствующие поля.
  #   prefix - строка с префиксом
  # override
  def prefix_parse(prefix)
    prefix_parts = prefix.split(' ')

    version_part_index = 0
    version = prefix_parts[version_part_index]
    @event.set('@version', version)

    log_level_part_index = 1
    log_level = prefix_parts[log_level_part_index]
    @event.set('logLevel', log_level)

    browser_part_index = 2
    browser_first_word = prefix_parts[browser_part_index]
    browser_first_word_index = prefix.index(browser_first_word)
    browser = prefix.slice(browser_first_word_index, prefix.length - 1)
    @event.set('browser', browser)
  end

  # Обработчик сообщения - ошибки.
  # override
  def error_message_handler
    current_message = @event.get('message')
    # В начале текста сообщения иногда выводится версия агента, убрать ее в отдельное поле индекса.
    current_message = remove_agent_version_from_message(current_message)
    @event.set('message', current_message)
    if current_message =~ /(?<message>.*?)\[(?<user>[^\[]*?):(?<tenant>\S+?)\](( TabId = (?<tabid>\S+))?)(?<stack_trace>.*)/m # rubocop:disable Metrics/LineLength
      message_text = Regexp.last_match[:message].to_s.strip
      user = Regexp.last_match[:user].to_s.strip
      tenant = Regexp.last_match[:tenant]
      tabid = Regexp.last_match[:tabid].to_s.strip
      stack_trace = Regexp.last_match[:stack_trace].to_s.strip

      @event.set('user', user)
      @event.set('tenant', tenant)
      @event.set('[@metadata][tenant]', tenant.downcase)
      @event.set('tabid', tabid) if !tabid.empty?
      @event.set('stackTrace', stack_trace)
      @event.set('message', message_text)
      # Добавить поле с обобщенным сообщением.
      set_generic_message(@event, 'genericMessage', message_text)
      parse_error_agent_call(message_text)
      @event.set('exceptionType', ErrorTypeParser.instance.get_type(@event))
    end
  end

  # Распарсить Info-запись лога.
  # override
  def info_message_handler
    super
    current_message = @event.get('message')
    # В начале текста сообщения иногда выводится версия агента, убрать ее в отдельное поле индекса.
    current_message = remove_agent_version_from_message(current_message)
    @event.set('message', current_message)
    # Добавились логи, где message - это json. В ней есть поле action, которое конфликтует с предыдущей разработкой.
    # Условие ниже исправляет это поле на action.other.
    # TODO: В новых версиях ожидаем переход на полноценный json, поэтому пока закрываем баг костылём.
    if current_message =~ /^\{.*?\"action\"\:.*\}/m
      @event.set('message', current_message.gsub('"action":', '"action.other":'))
    end

    if current_message =~ /\<\< Done in (?<duration>\d+) ms \((?<operation_description>.*)\)/
      @event.set('duration', Regexp.last_match[:duration].to_i)
      operation_description = Regexp.last_match[:operation_description]

      @parse_operation_methods.each do |parse_operation_method|
        return true if parse_operation_method.call(operation_description)
      end
    end

    if current_message =~ /INFO: AGENT.*method "(?<method>.+?)"/
      @event.set('operation', AGENT_CALL_OPERATION)
      @event.set('agentMethod', Regexp.last_match[:method])
    end
  end

  # Обработчик остальных сообщения (не ошибка и не метрика).
  # override
  def other_message_handler
    current_message = @event.get('message')
    # В начале текста сообщения иногда выводится версия агента, убрать ее в отдельное поле индекса.
    current_message = remove_agent_version_from_message(current_message)
    @event.set('message', current_message)
    if current_message =~ /(?<message>.*)\[(?<user>[^\[]*?):(?<tenant>\S+?)\]( TabId = (?<tabid>\S*))?\s*(?<additional_information>.*)?/m # rubocop:disable Metrics/LineLength
      tenant = Regexp.last_match[:tenant]
      tabid = Regexp.last_match[:tabid]
      message_text = Regexp.last_match[:message].to_s.strip
      additional_information = Regexp.last_match[:additional_information]

      @event.set('user', Regexp.last_match[:user].to_s.strip)
      @event.set('tabid', tabid) if !tabid.nil? && !tabid.empty?
      @event.set('additionalInformation', additional_information.strip) if !nil_or_empty?(additional_information)
      @event.set('tenant', tenant)
      @event.set('[@metadata][tenant]', tenant.downcase)
      @event.set('message', message_text)
    end
  end
end
