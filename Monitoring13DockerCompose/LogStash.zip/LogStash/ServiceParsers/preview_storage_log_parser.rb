require_relative '../utils'
require_relative '../log_level'
require_relative 'base_log_parser'

# Класс парсера логов PreviewStorage.
class PreviewStorageLogParser < BaseLogParser
  # Обработчик сообщения - ошибки.
  # override
  def error_message_handler
    current_message = @event.get('message')
    if current_message =~ /(?<exception>\w+(\.\w+)*?)( \(\S+\))?\:(?<message>.*?)($|\s{3,})((?<stack_trace>.*))?/m
      exception = Regexp.last_match[:exception]
      message_text = Regexp.last_match[:message].to_s.strip
      stack_trace = Regexp.last_match[:stack_trace].to_s.strip

      @event.set('exception', exception)
      @event.set('message', message_text)
      @event.set('stackTrace', stack_trace)
    end
    error_message_post_processing
  end

  # Распарсить Info-запись лога.
  # override
  def info_message_handler
    current_message = @event.get('message')
    # Распарсить Done request
    if current_message =~ /\<\< Done.* (?<duration>\d+) ms .* code: (?<status_code>\d+) \((?<info_description>.*), started = (?<started>.*)\)\s*(\[correlationId = (?<correlation_id>\S*)\])?/ # rubocop:disable Metrics/LineLength
      duration = Regexp.last_match[:duration].to_i
      status_code = Regexp.last_match[:status_code].to_i
      info_description = Regexp.last_match[:info_description]
      started = Regexp.last_match[:started]
      correlation_id = Regexp.last_match[:correlation_id]

      @event.set('operation', 'request')
      @event.set('duration', duration)
      @event.set('statusCode', status_code)
      @event.set('correlationId', correlation_id)
      parse_params(@event, info_description)
      begin
        date_time = Time.strptime(started, '%d.%m.%Y %H:%M:%S')
        logstash_timestamp = convert_to_logstash_time(date_time)
        @event.set('operationStartDate', logstash_timestamp)
      rescue StandardError
      end
    end
  end
end
