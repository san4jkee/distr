require_relative '../utils'
require_relative '../log_level'
require_relative 'base_log_parser'

# Класс парсера данных из csv. При обнаружении в названии шаблонов - должен вызывать другие парсеры.
class DataFromCSVParser < BaseLogParser
  def detect_special_csv_files
    parse_other_csv
  end

  # Функция парсера данных из неизвестных csv.
  def parse_other_csv
    @event.set('@timestamp', Time.now.to_s)
    return [@event]
  end
end
