require_relative '../utils'
require_relative '../log_level'
require_relative 'base_log_parser'

# Класс парсера лога веб-агента.
class WebAgentLogParser < BaseLogParser
  # Распарсить лог WebAgent.
  # override
  def parse_log
    extract_timestamp(@event)
    current_message = @event.get('message')
    set_service_start_time(@event)
    if current_message =~ /(?<version>[\d\.]*?)\s+(?<log_level>\S*?)\s+(?<module_name>\S*?):(?<module_line>\d*?)\s+(?<message>.*)/m # rubocop:disable Metrics/LineLength
      version = Regexp.last_match[:version]
      log_level = Regexp.last_match[:log_level]
      module_name = Regexp.last_match[:module_name]
      module_line = Regexp.last_match[:module_line]
      message_text = Regexp.last_match[:message].to_s.strip

      @event.set('@version', version)
      @event.set('logLevel', log_level)
      @event.set('moduleName', module_name)
      @event.set('moduleLine', module_line)
      @event.set('message', message_text)
      message_level_handler = @message_handlers[log_level]
      if message_level_handler.nil?
        other_message_handler
      else
        message_level_handler.call
      end
    end
    return [@event]
  end

  # Обработчик сообщения - ошибки.
  # override
  def error_message_handler
    current_message = @event.get('message')
    if current_message =~ /(?<message>.*)\[(?<user>[^\[]*?):(?<tenant>\S+)\]{1,}(?<stack_trace>.*)?/m
      message_text = Regexp.last_match[:message].to_s.strip
      tenant = Regexp.last_match[:tenant]
      user = Regexp.last_match[:user].to_s.strip
      stack_trace = Regexp.last_match[:stack_trace].to_s.strip

      @event.set('message', message_text)
      @event.set('user', user)
      @event.set('tenant', tenant)
      @event.set('[@metadata][tenant]', tenant.downcase)
      @event.set('stackTrace', stack_trace)
      # Добавить поле с обобщенным сообщением.
      set_generic_message(@event, 'genericMessage', message_text)
      @event.set('exceptionType', ErrorTypeParser.instance.get_type(@event))
    end
  end
end
