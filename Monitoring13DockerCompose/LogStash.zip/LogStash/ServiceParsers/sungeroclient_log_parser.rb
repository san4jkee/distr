require_relative '../utils'
require_relative '../log_level'
require_relative '../params_parser'
require_relative '../error_type_parser'
require_relative 'base_log_parser'

# Класс парсера логов SungeroClient.
class SungeroClientLogParser < BaseLogParser
  VERSION_PART_INDEX = 0
  private_constant :VERSION_PART_INDEX
  PROCESS_AND_THREAD_IDS_PART_INDEX = 1
  private_constant :PROCESS_AND_THREAD_IDS_PART_INDEX
  LOG_LEVEL_PART_INDEX = 2
  private_constant :LOG_LEVEL_PART_INDEX

  PROCESS_ID_PART_INDEX = 0
  private_constant :PROCESS_ID_PART_INDEX
  THREAD_ID_PART_INDEX = 1
  private_constant :THREAD_ID_PART_INDEX

  # Распарсить Info-запись лога.
  # override
  def info_message_handler
    super
    current_message = @event.get('message')
    # Распарсить Done
    if current_message =~ /\<\< Done in (?<duration>\d+) ms \((?<params>.*)\)/
      prefix = 'operation'
      @event.set('infoType', prefix)
      @event.set('duration', Regexp.last_match[:duration].to_i)
      parse_params(@event, Regexp.last_match[:params], true)
      return
    end

    # Распарсить долгие запросы к СП
    if current_message =~ /(?<request_service_name>\w+)(\\|\/)(?<request_name>\w+) \((?<params>.*)\)/
      @event.set('requestName', Regexp.last_match[:request_name])
      @event.set('requestServiceName', Regexp.last_match[:request_service_name])
      params = Regexp.last_match[:params]
      parse_request(params)
      return
    end

    # Распарсить используемую память клиентом
    if current_message =~ /Private = (?<private>\d+) MB, virtual = (?<virtual>\d+)/
      @event.set('privateMemory', Regexp.last_match[:private].strip.to_i)
      @event.set('virtualMemory', Regexp.last_match[:virtual].strip.to_i)
      return
    end

    # Распарсить виджеты
    logger = @event.get('logger')
    parse_widget(current_message) if logger.end_with?('.WidgetLogger')
  end

  # Распарсить информацию по виджетам
  #   message_text - текст сообщения
  def parse_widget(message_text)
    if message_text =~ /(?<widget_operation>.*)\. (?<params>.*)/
      prefix = 'widget'
      @event.set('infoType', prefix)
      widget_operation = Regexp.last_match[:widget_operation].strip
      # Добавить поле тип Folder, если это операция перехода в папку
      @event.set('widgetType', 'Folder') if widget_operation == 'Execute folder widget'
      @event.set("#{prefix}Operation", widget_operation)
      parse_params(@event, Regexp.last_match[:params])
    end
  end
end
