require_relative '../utils'
require_relative '../log_level'
require_relative '../dictionary_extension'

# Базовый класс парсера логов.
class BaseLogParser
  # Конструктор.
  #   event - текущее событие LogStash.
  def initialize(event)
    @event = event
    set_service_name
    @message_handlers = InsensetiveHash.new
    @message_handlers[LogLevel::ERROR] = method(:error_message_handler)
    @message_handlers[LogLevel::FATAL] = method(:error_message_handler)
    @message_handlers[LogLevel::INFO] = method(:info_message_handler)
  end

  # Установить имя сервиса
  # virtual
  def set_service_name; end

  # Раcпарсить префикс в строке на соответствующие поля.
  #   prefix - строка с префиксом
  # virtual
  def prefix_parse(prefix)
    prefix_parts = prefix.split(' ')

    # Вытащить остальные поля из префикса
    version_part_index = 0
    version = prefix_parts[version_part_index]
    @event.set('@version', version)
    process_and_thread_ids_part_index = 1
    process_and_thread_ids = prefix_parts[process_and_thread_ids_part_index]
    log_level_part_index = 2
    log_level = prefix_parts[log_level_part_index]
    @event.set('logLevel', log_level)
    logger_parg_index = 3
    logger = prefix_parts[logger_parg_index]
    @event.set('logger', logger)

    # Разбить ИД процесса и ИД потока на отдельные поля
    process_and_thread_ids_parts = process_and_thread_ids.split('+')
    process_id_part_index = 0
    process_id = process_and_thread_ids_parts[process_id_part_index]
    @event.set('processId', process_id)
    thread_id_part_index = 1
    thread_id = process_and_thread_ids_parts[thread_id_part_index]
    @event.set('threadId', thread_id)
  end

  # Распарсить лог.
  # virtual
  def parse_log
    extract_timestamp(@event)
    current_message = @event.get('message')
    set_service_start_time(@event)
    if current_message =~ /(?<prefix>.*?) - (?<message>.*)/m
      prefix = Regexp.last_match[:prefix]
      message_text = Regexp.last_match[:message].strip

      @event.set('message', message_text)
      prefix_parse(prefix)
      log_level = @event.get('logLevel')
      message_level_handler = @message_handlers[log_level]
      if message_level_handler.nil?
        other_message_handler
      else
        message_level_handler.call
      end
    end
    return [@event]
  end

  # Завершающая обработка сообщения-ошибки
  def error_message_post_processing
    set_exception_method(@event)
    process_aggregate_exception(@event)
    set_generic_message(@event, 'genericMessage', @event.get('message'))
    @event.set('exceptionType', ErrorTypeParser.instance.get_type(@event))
  end

  # Обработчик сообщения - ошибки.
  # virtual
  def error_message_handler
    current_message = @event.get('message')
    if current_message =~ /(?<message>.*?)\[(?<user>[^\[]*?):(?<tenant>\S+?)\]\s*((?<exception>\w+(\.\w+)+)\ ?(\([\w\.]+?\))?: (?<stack_trace>.*))?/m # rubocop:disable Metrics/LineLength
      message_text = Regexp.last_match[:message].to_s.strip
      user = Regexp.last_match[:user].to_s.strip
      tenant = Regexp.last_match[:tenant]
      exception = Regexp.last_match[:exception]
      stack_trace = Regexp.last_match[:stack_trace].to_s.strip

      @event.set('tenant', tenant)
      @event.set('[@metadata][tenant]', tenant.downcase)
      @event.set('user', user)
      @event.set('exception', exception)
      @event.set('stackTrace', stack_trace)
      @event.set('message', message_text)
    end
    error_message_post_processing
  end

  # Обработчик сообщения - метрики.
  # virtual
  def info_message_handler
    current_message = @event.get('message')
    if current_message =~ /(?<message>.*)\[(?<user>[^\[]*?):(?<tenant>\S+)\]/m
      message_text = Regexp.last_match[:message].to_s.strip
      user = Regexp.last_match[:user].to_s.strip
      tenant = Regexp.last_match[:tenant]

      @event.set('message', message_text)
      @event.set('user', user)
      @event.set('tenant', tenant)
      @event.set('[@metadata][tenant]', tenant.downcase)
    end
  end

  # Обработчик остальных сообщения (не ошибка и не метрика).
  # virtual
  def other_message_handler
    current_message = @event.get('message')
    if current_message =~ /(?<message>.*)\[(?<user>[^\[]*?):(?<tenant>\S+)\]\s*(?<additional_information>.*)?/m
      message_text = Regexp.last_match[:message].to_s.strip
      user = Regexp.last_match[:user].to_s.strip
      tenant = Regexp.last_match[:tenant]
      additional_information = Regexp.last_match[:additional_information]

      @event.set('message', message_text)
      @event.set('user', user)
      @event.set('tenant', tenant)
      @event.set('[@metadata][tenant]', tenant.downcase)
      @event.set('additionalInformation', additional_information.strip) if !nil_or_empty?(additional_information)
    end
  end
end
