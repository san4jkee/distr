require_relative '../utils'
require_relative '../log_level'
require_relative 'base_log_parser'

# Класс парсера логов workflow-process-server.
class WorkflowProcessLogParser < BaseLogParser
  # Обработчик сообщения - ошибки.
  # override
  def error_message_handler
    current_message = @event.get('message')
    if current_message =~ /(?<message>.*?)\[(?<user>[^\[]*?):(?<tenant>.*?)\](\W*(?<exception>\w+\.+[\w\.]+)\: (?<stack_trace>.*))?/m # rubocop:disable Metrics/LineLength
      user = Regexp.last_match[:user].to_s.strip
      tenant = Regexp.last_match[:tenant].to_s.strip
      message_text = Regexp.last_match[:message].to_s.strip
      exception = Regexp.last_match[:exception]
      stack_trace = Regexp.last_match[:stack_trace].to_s.strip

      @event.set('user', user)
      @event.set('tenant', tenant)
      @event.set('[@metadata][tenant]', tenant.downcase)
      @event.set('message', message_text)
      @event.set('exception', exception)
      @event.set('stackTrace', stack_trace)
      error_message_post_processing
    end
  end
end
