require_relative '../utils'
require_relative '../log_level'
require_relative 'base_log_parser'
require_relative '../params_parser'

# Класс парсера логов SungeroServer
class SungeroServerLogParser < BaseLogParser
  # Установить имя сервиса
  # override
  def set_service_name
    name_sungero_server = 'SungeroServer'
    @event.set('serviceName', name_sungero_server)
    @event.set('[@metadata][serviceName]', name_sungero_server.downcase)
  end

  # Распарсить Info-запись лога.
  # override
  def info_message_handler
    super
    current_message = @event.get('message')
    # Распарсить Done
    if current_message =~ /\<\< Done in (?<duration>\d+) ms \((?<info_description>.*), started = .*\)/
      @event.set('duration', Regexp.last_match[:duration].to_i)
      parse_params(@event, Regexp.last_match[:info_description], true)
      if current_message =~ /\<\< Done in (?<duration>\d+) ms \((?<params>.*)\)/
        prefix = 'operation'
        @event.set('infoType', prefix)
        parse_params(@event, Regexp.last_match[:params], true)
        return
      end
    end

    # Распарсить долгие запросы к СП
    if current_message =~ /(?<request_service_name>\w+)(\\|\/)(?<request_name>\w+) \((?<params>.*)\)/
      @event.set('requestName', Regexp.last_match[:request_name])
      @event.set('requestServiceName', Regexp.last_match[:request_service_name])
      params = Regexp.last_match[:params]
      parse_request(params)
      return
    end
  end

  # Обработчик сообщения - ошибки.
  # override
  def error_message_handler
    current_message = @event.get('message')
    # Если в сообщении ошибка запроса к SQL - может сломать нам все поля, т.к. запрос может быть любым.
    # Заранее отлавливаем ситуацию и, не смотря на потерю информации, сокращаем сообщение до минимального.
    if current_message =~ /could not execute query \[.*?\] Contact your system administrator \[(?<user>[^\[]*?):(?<tenant>\S+)\][\s\S]*?(?<stack>---> System.Exception[\s\S]*)/m # rubocop:disable Metrics/LineLength
      @event.set('message', 'Could not execute query')
      @event.set('user', Regexp.last_match[:user].strip)
      @event.set('tenant', Regexp.last_match[:tenant].strip)
      @event.set('stackTrace', Regexp.last_match[:stack].strip)
      @event.set('exceptionType', ErrorTypeParser.instance.get_type(@event))
      set_generic_message(@event, 'genericMessage', 'Could not execute query')
      return
    elsif current_message =~ /(?<message>.*?)\[(?<user>[^\[]*?):(?<tenant>\S+?)\]\s*((?<exception>\w+(\.\w+)+)\ ?(\([\w\.]+?\))?: (?<stack_trace>.*))?/m # rubocop:disable Metrics/LineLength
      message_text = Regexp.last_match[:message].to_s.strip
      user = Regexp.last_match[:user].to_s.strip
      tenant = Regexp.last_match[:tenant]
      exception = Regexp.last_match[:exception]
      stack_trace = Regexp.last_match[:stack_trace].to_s.strip

      @event.set('tenant', tenant)
      @event.set('[@metadata][tenant]', tenant.downcase)
      @event.set('user', user)
      @event.set('exception', exception)
      @event.set('stackTrace', stack_trace)
      @event.set('message', message_text)
      error_message_post_processing
    end
  end
end
