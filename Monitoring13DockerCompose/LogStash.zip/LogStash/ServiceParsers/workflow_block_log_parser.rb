require_relative '../utils'
require_relative '../log_level'
require_relative 'base_log_parser'

# Класс парсера логов workflow-block-server.
class WorkflowBlockLogParser < BaseLogParser
  # Обработчик сообщения - ошибки.
  # override
  def error_message_handler
    current_message = @event.get('message')
    if current_message =~ /(?<message>[\s\S]+?)(?<exception>[\w\.]+)\: (?<stack_trace>[\s\S\n\r]*)\[workflow\W*:\W*(?<tenant>.*?)\]/m # rubocop:disable Metrics/LineLength
      tenant = Regexp.last_match[:tenant].to_s.strip
      message_text = Regexp.last_match[:message].to_s.strip
      exception = Regexp.last_match[:exception]
      stack_trace = Regexp.last_match[:stack_trace].to_s.strip

      @event.set('user', 'workflow')
      @event.set('tenant', tenant)
      @event.set('[@metadata][tenant]', tenant.downcase)
      @event.set('message', message_text)
      @event.set('exception', exception)
      @event.set('stackTrace', stack_trace)
    end
    error_message_post_processing
  end
end
