require_relative '../utils'
require_relative '../log_level'
require_relative 'base_log_parser'

# Класс парсера логов веб-сервера.
class WebServerLogParser < BaseLogParser
  # Распарсить Info-запись лога.
  # override
  def info_message_handler
    super
    current_message = @event.get('message')
    # Распарсить Done
    if current_message =~ /\<\< Done in (?<duration>\d+) ms (?<info_description>.*)/
      @event.set('duration', Regexp.last_match[:duration].to_i)
      info_description = Regexp.last_match[:info_description]
      # Если в параметрах указан API - разбить его и вывести в отдельные поля.
      if info_description =~ /\(api = (?<controllerName>[\w-]*).(?<actionName>[\w-]*).*/
        controller_name = Regexp.last_match[:controllerName]
        action_name = Regexp.last_match[:actionName]
        @event.set('controllerName', controller_name)
        @event.set('actionName', "#{controller_name}.#{action_name}")
      # Если в параметрах указана генерация отчёта - распарсить все параметры в скобках.
      elsif info_description =~ /\((?<report_params>generate report = .*?)\)/
        parse_params(@event, Regexp.last_match[:report_params])
      end
    end
  end

  # Обработчик сообщения - ошибки.
  # override
  def error_message_handler
    current_message = @event.get('message')
    if current_message =~ /(?<message>.*?)\[(?<user>[^\[]*?):(?<tenant>\S+?)\]\s*(?<exception>.*?)\:((?<stack_trace>[\s\S\n\r]*))?/m # rubocop:disable Metrics/LineLength
      message_text = Regexp.last_match[:message].to_s.strip
      user = Regexp.last_match[:user].to_s.strip
      tenant = Regexp.last_match[:tenant]
      exception = Regexp.last_match[:exception].to_s.strip
      stack_trace = Regexp.last_match[:stack_trace].to_s.strip

      @event.set('tenant', tenant)
      @event.set('[@metadata][tenant]', tenant.downcase)
      @event.set('user', user)
      @event.set('stackTrace', stack_trace)
      @event.set('exception', exception)
      @event.set('message', message_text)
    end
    error_message_post_processing
  end
end
