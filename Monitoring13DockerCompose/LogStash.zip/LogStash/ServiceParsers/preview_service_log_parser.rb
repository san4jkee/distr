require_relative '../utils'
require_relative '../log_level'
require_relative 'base_log_parser'
require_relative '../params_parser'

# Класс парсера логов PreviewService
class PreviewServiceLogParser < BaseLogParser
  # Обработчик сообщения - ошибки.
  # override
  def error_message_handler
    current_message = @event.get('message')
    if current_message =~ /(?<message>.*?)($|\s{3,})(?<exception>\w+(\.\w+)*?)( \(\S+\))?\:((?<stack_trace>.*))?/m
      message_text = Regexp.last_match[:message].to_s.strip
      exception = Regexp.last_match[:exception]
      stack_trace = Regexp.last_match[:stack_trace].to_s.strip

      # Распарсить сообщения с несконвертированными документами
      if message_text =~ /Error while processing document\s*\((?<additional_information>.*?\)?)\)/m
        @event.set('operation', 'conversion')
        additional_information = Regexp.last_match[:additional_information].strip
        parse_add_info(additional_information)
      end

      @event.set('message', message_text)
      @event.set('exception', exception)
      @event.set('stackTrace', stack_trace)
      error_message_post_processing
    end
  end

  # Распарсить Info-запись лога.
  # override
  def info_message_handler
    current_message = @event.get('message')
    # Распарсить старт запроса
    if current_message =~ /\>\> Start (?<operation>.+?)\((?<additional_information>.*?)\) \[correlationId = (?<correlationid>\S*)\]/ # rubocop:disable Metrics/LineLength
      @event.set('operation', Regexp.last_match[:operation].strip)
      @event.set('correlationId', Regexp.last_match[:correlationid].strip)
      parse_add_info(Regexp.last_match[:additional_information].strip)
      return
    end

    # Распарсить загрузку файлов
    if current_message =~ /\<\< Done (?<operation>.+?) in (?<duration>\d+) ms \((?<additional_information>.*?)\)/ # rubocop:disable Metrics/LineLength
      @event.set('operation', Regexp.last_match[:operation].strip)
      @event.set('duration', Regexp.last_match[:duration].to_i)
      parse_add_info(Regexp.last_match[:additional_information].strip)
      return
    end

    # Распарсить операцию с параметрами
    if current_message =~ /\<\< Done.* (?<duration>\d+) ms (?<operation>[^\[]+?)\((?<info_description>.*)\)\s*(\[correlationId = (?<correlation_id>\S*)\])?/ # rubocop:disable Metrics/LineLength
      @event.set('operation', Regexp.last_match[:operation].strip)
      @event.set('duration', Regexp.last_match[:duration].to_i)
      @event.set('correlationId', Regexp.last_match[:correlation_id])
      parse_params(@event, Regexp.last_match[:info_description].strip)
      return
    end

    # Распарсить остальные операции
    if current_message =~ /\<\< Done.* (?<duration>\d+) ms (?<operation>.+?)\[correlationId = (?<correlation_id>\S*)\](?<additional_information>.*)/ # rubocop:disable Metrics/LineLength
      @event.set('operation', Regexp.last_match[:operation].strip)
      @event.set('duration', Regexp.last_match[:duration].to_i)
      @event.set('correlationId', Regexp.last_match[:correlation_id])
      parse_add_info(Regexp.last_match[:additional_information].strip)
      return
    end

    # Распарсить сообщения с несконвертированными документами
    if current_message =~ /Error while processing document\s*\((?<additional_information>.*?\)?)\)(?<stack_trace>[\s\S]*)?/m # rubocop:disable Metrics/LineLength
      @event.set('operation', 'conversion')
      @event.set('stackTrace', Regexp.last_match[:stack_trace].to_s.strip)
      additional_information = Regexp.last_match[:additional_information].strip
      message_text = 'Error while processing document (' + additional_information + ')'
      @event.set('message', message_text)
      set_generic_message(@event, 'genericMessage', message_text)
      parse_add_info(additional_information)
    end
  end

  # Распарсить дополнительную информацию
  def parse_add_info(additional_information)
    if additional_information =~ /(^(card)?id ?= ?(?<id>\d+))?,? ?(bin(ary)?(data)?id ?= ?(?<binaryid>[A-Za-z0-9\-]+))?,? ?(dataType ?= ?(?<datatype>\w+))?,? ?(bytes ?= ?(?<bytes>\d+))?,? ?(pages? ?= ?\(?(?<pages>[^)\n]*)\)?)?,? ?(started ?= ?(?<started>.*))?/im # rubocop:disable Metrics/LineLength
      set_not_nil_params('id', Regexp.last_match[:id])
      set_not_nil_params('binaryDataId', Regexp.last_match[:binaryid])
      set_not_nil_params('dataType', Regexp.last_match[:datatype])
      set_not_nil_params('pages', Regexp.last_match[:pages])
      set_not_nil_params('started', Regexp.last_match[:started])
      bytes = Regexp.last_match[:bytes]
      @event.set('bytes', bytes.to_i) if !nil_or_empty?(bytes)
    else set_not_nil_params('additionalInformation', additional_information)
    end
  end

  # Присвоение не пустых параметров
  def set_not_nil_params(name, value)
    @event.set(name, value.strip) if !nil_or_empty?(value)
  end
end
