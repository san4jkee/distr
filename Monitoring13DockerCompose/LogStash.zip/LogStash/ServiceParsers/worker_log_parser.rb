require_relative '../utils'
require_relative '../log_level'
require_relative 'base_log_parser'
require_relative '../params_parser'

# Класс парсера логов Worker
class WorkerLogParser < BaseLogParser
  # Распарсить Info-запись лога.
  # override
  def info_message_handler
    super
    current_message = @event.get('message')
    # Распарсить Done
    if current_message =~ /\<\< Done.* (?<duration>\d+) ms.*\((?<info_description>.*), started = .*\)\s*(\[id = (?<tab_id>\S*)\])?/ # rubocop:disable Metrics/LineLength
      @event.set('tabId', Regexp.last_match[:tab_id])
      @event.set('duration', Regexp.last_match[:duration].to_i)
      parse_params(@event, Regexp.last_match[:info_description], true)
    end
  end

  # Обработчик сообщения - ошибки.
  # override
  def error_message_handler
    current_message = @event.get('message')
    if current_message =~ /(?<message>.*?)\[(?<user>[^\[]*?):(?<tenant>[^\]]*?)\]($|\s*)((?<exception>\S+(\.\S+)*?)( \(\S+\))?\:((?<stack_trace>.*))?)?/m # rubocop:disable Metrics/LineLength
      message_text = Regexp.last_match[:message].strip
      user = Regexp.last_match[:user].to_s.strip
      tenant = Regexp.last_match[:tenant]
      exception = Regexp.last_match[:exception]
      stack_trace = Regexp.last_match[:stack_trace].to_s.strip

      @event.set('user', user)
      @event.set('tenant', tenant)
      @event.set('[@metadata][tenant]', tenant.downcase)
      @event.set('message', message_text)
      @event.set('exception', exception)
      @event.set('stackTrace', stack_trace)
      error_message_post_processing
    end
  end

  # Обработчик остальных сообщения (не ошибка и не метрика).
  # override
  def other_message_handler
    current_message = @event.get('message')
    if current_message =~ /(?<message>.*?)\((?<additionalInformation>.*?)\) +\[(?<user>[^\[]*?):(?<tenant>[^\]]*?)\]/m # rubocop:disable Metrics/LineLength
      additional_information = Regexp.last_match[:additionalInformation].to_s.strip
      parse_task_params(additional_information)
      @event.set('user', Regexp.last_match[:user].to_s.strip)
      @event.set('tenant', Regexp.last_match[:tenant])
    end
  end

  # Парсинг параметров в логах уровня Warn
  def parse_task_params(add_info)
    if add_info =~ /(\w+ ?= ?[^,\n\r]+,? ?)+/m
      task_info = add_info.strip.split(',')
      task_info.each do |param|
        key = param.split('=')[0].strip
        param = param.gsub("'", '') unless param.scan("'").empty?
        if param.split('=')[1].nil?
          if @event.get('additionalInformation').to_s == ""
            @event.set('additionalInformation', key.strip)
          else
            @event.set('additionalInformation', @event.get('additionalInformation').to_s + ", " + key.strip)
          end
        else
          @event.set(camelize(key, :lower), param.split('=')[1].strip)
        end
      end
    else
      @event.set('additionalInformation', add_info.strip)
    end
  end
end
