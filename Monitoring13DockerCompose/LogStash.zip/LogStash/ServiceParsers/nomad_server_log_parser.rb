require_relative '../utils'
require_relative '../log_level'
require_relative 'base_log_parser'
require_relative '../params_parser'

# Класс парсера логов Nomad
class NomadServerLogParser < BaseLogParser
  # Установить имя сервиса
  # override
  def set_service_name
    service_name = 'Nomad'
    @event.set('serviceName', service_name)
    @event.set('[@metadata][serviceName]', service_name.downcase)
  end

  # Распарсить лог Nomad
  # override
  def parse_log
    fields_names = ['@timestamp', 'logLevel', 'message', 'additionalInformation', 'duration', 'code', 'user',
                    'application', 'userAgent', 'requestUrl', 'requestNumber', 'ip', 'nomadVersion', 'adapterVersion']
    current_message = @event.get('message')
    return [@event] if check_exception_of_rule(current_message)

    current_message = current_message.split("\t")

    # Создать и заполнить временную хеш-таблицу с названиями полей в elastic
    hash_table = {}
    i = 0
    fields_names.each do |field_name|
      hash_table[field_name] = current_message[i]
      i += 1
    end

    # Установить метку времени в отдельный атрибут события
    time = Time.strptime(hash_table['@timestamp'], '%Y-%m-%d %H:%M:%S.%L %z')
    logstash_timestamp = convert_to_logstash_time(time)
    @event.set('@timestamp', logstash_timestamp)
    hash_table.delete('@timestamp')

    # Распарсить сообщение, выделить стек
    log_level = hash_table['logLevel']
    hash_table.delete('logLevel')
    message = hash_table['message']
    hash_table.delete('message')
    set_stack(message, log_level)
    set_generic_message(@event, 'genericMessage', @event.get('message').strip)
    @event.set('logLevel', log_level)

    # Перевести значение duration в целое число
    @event.set('duration', hash_table['duration'].to_i) unless hash_table['duration'].empty?
    hash_table.delete('duration')

    # Выделить имя пользователя, локализацию и тенант, если они указаны
    unless hash_table['user'].empty?
      user_data = hash_table['user'].split(' ')
      @event.set('user', user_data[0].to_s.strip)
      @event.set('localization', user_data[1].to_s.strip)
      @event.set('tenant', user_data[2].to_s.strip)
    end
    hash_table.delete('user')

    # Заполнить остальные поля
    hash_table.each_key { |key| @event.set(key, hash_table[key].to_s.strip) if !nil_or_empty?(hash_table[key]) }
    @event.set('exceptionType', ErrorTypeParser.instance.get_type(@event))
    return [@event]
  end

  # Выделить стек вызова из сообщения
  def set_stack(message_with_stack, log_level)
    @event.set('message', message_with_stack.strip)
    @event.set('stackTrace', '')
    if log_level == 'Error'
      if message_with_stack =~ /(?<message>.*?)(\n| {3,})(?<stack>.*)?/m
        message = Regexp.last_match[:message].to_s.strip
        # Выделить и отформатировать строку трейсов
        stack = Regexp.last_match[:stack].to_s
        stack = stack.squeeze(' ').gsub(' в ', "\n  в ").gsub("\nв ", "\n  в ").strip
        @event.set('message', message)
        @event.set('stackTrace', stack)
      end
    end
  end

  # Проверка на нестандартные строки, которые есть в старых версиях NOMAD. Пример такой строки ниже:
  # 2020-02-02 00:00:39.367 +04:00 ************** w3wp started (Nomad=2.9.1.32690, Sungero=2.9.7.0006) **************
  def check_exception_of_rule(current_message)
    if current_message =~ /(?<timestamp>.+?) \*+ (?<message>.*?)\((?<additionalInformation>.+?)\) \*+.*/m
      timestamp = Regexp.last_match[:timestamp].to_s.strip
      time = Time.strptime(timestamp, '%Y-%m-%d %H:%M:%S.%L %z')
      logstash_timestamp = convert_to_logstash_time(time)
      @event.set('@timestamp', logstash_timestamp)
      @event.set('message', Regexp.last_match[:message].to_s.strip)
      @event.set('additionalInformation', Regexp.last_match[:additionalInformation].to_s.strip)
      @event.set('logLevel', 'Info')
      return true
    else
      return false
    end
  end
end
