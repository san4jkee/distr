﻿require 'yaml'

# Класс определяющий тип ошибки.
class ErrorTypeParser
  CONFIG_FILE = 'exceptionType.yml'.freeze
  SECTIONS = %w[exception message genericMessage stackTrace].freeze
  REGEX_PREFIX = '(regex)'.freeze
  NOT_PREFIX = '(not)'.freeze

  def config
    @config ||= initialize_config
  end

  # Конструктор.
  def initialize_config
    config_full_path = File.join(File.dirname(__FILE__), CONFIG_FILE)
    return YAML.safe_load(File.read(config_full_path, encoding: 'utf-8')) if File.exist?(config_full_path)

    return YAML.safe_load('empty:')
  end

  # Одиночка.
  def self.instance
    return @@instance
  end
  @@instance = ErrorTypeParser.new # rubocop:disable Style/ClassVars
  private_class_method :new

  # Проверить начинается ли исходное значение с префикса
  #   value - исходное значение
  #   prefix - префикс
  def start_with_prefix?(value, prefix)
    return false if value.nil?

    return value.start_with?(prefix)
  end

  # Подготовить выражение, обработав все префиксы в нем
  #   expression - исходное выражение
  def prapare_expression(expression)
    # Проверить наличия префикса (not)
    is_negative_expression = start_with_prefix?(expression, NOT_PREFIX)
    # Удалить префик (not) если он есть
    expression = expression[NOT_PREFIX.length, expression.length] if is_negative_expression
    # Проверить наличия префикса (refex)
    is_regex = start_with_prefix?(expression, REGEX_PREFIX)
    # Удалить префик (regex) если он есть
    expression = expression[REGEX_PREFIX.length, expression.length] if is_regex
    return {
      'is_negative_expression': is_negative_expression,
      'is_regex': is_regex,
      'value': expression
    }
  end

  # Проверить использование специальных конструкций в выражениях
  #   is_negative_expression - признак, который показывает, есть конструкция not или нет.
  #   section_value - значение из yaml файла.
  #   event_value - значение из event LogStash'а.
  def check_special_expressions(is_negative_expression, section_value, event_value) # rubocop:disable Metrics/CyclomaticComplexity, Metrics/PerceivedComplexity, Metrics/LineLength
    if section_value == '*' || section_value.to_s.empty?
      # Выражение без отрицания
      if !is_negative_expression
        # Считаем что выражение не влият на критичности, если выражение нет в конфиге или оно может иметь любое значение
        return 0 if section_value.nil? || section_value == '*'

        # Считаем что есть совпадение, если выражение и значение поля пустые
        return 1 if section_value.to_s.empty? && event_value.to_s.empty?
      else
        # Считаем что есть совпадение, потому что отрицание(not) с * означает, что у поля не может быть значения
        return 1 if section_value == '*' && event_value.to_s.empty?

        # Считаем что есть совпадение, потому что отрицание(not) с пустой строкой означает, что поле не пустое
        return 1 if section_value.to_s.empty? && !event_value.to_s.empty?
      end
      return -1
    end
    # Считаем что нет совпадение, если евенте нет поля, а у exception'a оно задано.
    return -1 if event_value.nil?

    return nil
  end

  # Проверить совпадение.
  #   event_value - значение из event LogStash'а.
  #   section_value - значение из yaml файла.
  def check_matching(event_value, section_value) # rubocop:disable Metrics/CyclomaticComplexity, Metrics/PerceivedComplexity, Metrics/LineLength
    expression = prapare_expression(section_value)

    # Проверить выражения со значениями empty,* и nil
    result_checking = check_special_expressions(expression[:is_negative_expression], expression[:value], event_value)
    return result_checking if !result_checking.nil?

    # Проверить является ли выражение регуляркой.
    if expression[:is_regex]
      if event_value =~ Regexp.new(expression[:value])
        return 1 if !expression[:is_negative_expression]

        return -1
      end
    elsif event_value.include? expression[:value]
      return 1 if !expression[:is_negative_expression]

      return -1
    end
    return -1 if !expression[:is_negative_expression]

    # Если индекс выражения отрицательный (конструкция с not) и совпадений не нашлось, то возвращаем результат 0.1,
    # потому что явное совпадение одного поля должно имееть больший вес(1),
    # чем отсутствие выражения в поле при поиске с констукцией not
    return 0.1
  end

  # Получить тип ошибки в виде текста
  #   event - текущее событие LogStash.
  def get_type(event)
    service_name = event.get('serviceName')
    current_type = 'unknown'
    actual_matching_count = 0
    # Проверить, что определён serviceName и внутренние данные event
    if !service_name.nil? && !config[service_name].nil?
      # Начать проверку по каждому из типов - Critical и Noncritical
      config[service_name].each do |types|
        # Зафиксировать текущий тип
        type = types[0]
        config[service_name][type].each do |exception_node|
          matching_result = 0
          matching_count = 0
          # Поиск в файле по каждой секции (например, message, genericMessage и т.д.). Секции перечислены вначале файла
          SECTIONS.each do |section|
            matching_result = check_matching(event.get(section), exception_node[section])
            # Если не найдено совпадений - продолжить проверку, иначе указать необходимость смены типа ошибки
            break if matching_result == -1

            matching_count += matching_result
          end
          # Если найден другой тип ошибки - изменить тип на текущий
          if matching_count > actual_matching_count
            actual_matching_count = matching_count
            current_type = type
          end
        end
      end
    end
    return current_type
  end
end
