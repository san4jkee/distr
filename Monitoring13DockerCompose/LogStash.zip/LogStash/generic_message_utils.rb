# Сделать исходную строку обобщенной.
#   message_text - исходная строка.
def make_generic_message(message_text)
  message_text = remove_url(message_text)
  message_text = remove_path(message_text)
  message_text = remove_guid(message_text)
  message_text = remove_hex_num(message_text)
  message_text = remove_last_version(message_text)
  message_text = remove_numbers(message_text)
  message_text = remove_version_in_number(message_text)
  message_text = remove_quoted(message_text)
  message_text = remove_datetime(message_text)
  message_text = remove_requestid(message_text)
  message_text = message_text.slice(0, 250)
  return message_text
end

# Удалить ссылки из текста
#   message_text - исходная строка.
def remove_url(message_text)
  return message_text.gsub(/https?\:\/\/\S+/mi, '{url}')
end

# Удалить пути из текста
#   message_text - исходная строка.
def remove_path(message_text)
  return message_text.gsub(/([a-z]\:\\{1,2}|\\{2,4})([^\"\'\:\n]+\\{1,2})*([^\"\'\:\n])+/mi, '{path}')
end

# Удалить GUID'ы из текста
#   message_text - исходная строка.
def remove_guid(message_text)
  return message_text.gsub(/[a-z\d]{8}\-[a-z\d]{4}\-[a-z\d]{4}\-[a-z\d]{4}\-[a-z\d]{12}/mi, '{GUID}')
end

# Удалить шестнадцатеричные числа из текста
#   message_text - исходная строка.
def remove_hex_num(message_text)
  return message_text.gsub(/\b(0x)?[a-f\d]{7}[a-f\d]+\b/mi, '{N}')
end

# Удалить версию с номером last из текста
#   message_text - исходная строка.
def remove_last_version(message_text)
  return message_text.gsub(/(version = )last/mi, '\1{N}')
end

# Удалить числа из текста
#   message_text - исходная строка.
def remove_numbers(message_text)
  return message_text.gsub(/\b(\d+)\b/mi, '{N}')
end

# Удалить ИД и номер версии из текста
#   message_text - исходная строка.
def remove_version_in_number(message_text)
  return message_text.gsub(/\b\d+v\d+\b/mi, '{N}')
end

# Удалить строки, заключенные в одинарные или двойные кавычки
#  message_text - исходная строка
def remove_quoted(message_text)
  message_text = message_text.gsub(/\"[^\"\{\}]+\"/mi, '"{S}"')
  return message_text.gsub(/\'[^\'\{\}]+\'/mi, '\'{S}\'')
end

# Удалить строки, соответствующие дате со временем
#  message_text - исходная строка
def remove_datetime(message_text)
  return message_text.gsub(/\{N\}\.\{N\}\.\{N\} \{N\}\:\{N\}\:\{N\}/mi, '{date}')
end

# Удалить requestId.
#  message_text - исходная строка.
def remove_requestid(message_text)
  return message_text.gsub(/(requestId=)\w+/, '\1{S}')
end
