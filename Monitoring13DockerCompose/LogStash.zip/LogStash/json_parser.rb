require_relative 'global_constants'
require 'json'

# Класс определения json поля.
class JsonParser
  # Проверить валидный ли json.
  def self.valid_json?(json)
    return false if json.nil?

    JSON.parse(json)
    return true
  rescue JSON::ParserError
    return false
  end

  # Определить json поле.
  def self.detect_json_field(event)
    message = event.get(MESSAGE_FIELD)
    if !message.empty?
      if message.downcase.start_with?(JSON_PREFIX_DOWNCASE)
        json = message[JSON_PREFIX_DOWNCASE.length..-1]
      elsif message.start_with?('{') && message.end_with?('}')
        json = message
      end

      event.set('json_field', json) if JsonParser.valid_json?(json)
    end
  end
end
