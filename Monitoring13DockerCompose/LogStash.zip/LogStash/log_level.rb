# Перечисление уровней логирования.
module LogLevelEnum
  FATAL = 'fatal'.freeze
  ERROR = 'error'.freeze
  WARNING = 'warning'.freeze
  INFO = 'info'.freeze
  DEBUG = 'debug'.freeze
  TRACE = 'trace'.freeze
end

# Класс для уровней логирования.
class LogLevel
  include LogLevelEnum

  # Вернуть признак наличия ошибки.
  def self.error_or_fatal?(log_level)
    return log_level.casecmp(LogLevel::FATAL).zero? || log_level.casecmp(LogLevel::ERROR).zero?
  end
end
