#!/bin/bash
docker rm grafana --force
docker run -p 3000:3000 --detach --name grafana -v grafana-storage:/var/lib/grafana grafana:1.0 