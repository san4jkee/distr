# -*- coding: utf-8 -*-
#!/usr/bin/env python

import requests
import os
import json
import sys


def main(argv):
    url = "http://admin:1Qwerty@127.0.0.1"
    directory = os.path.join(os.path.abspath(os.curdir), 'dashboards')

    if len(argv) > 0:
        url = argv[0]

    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    for root, d, file in os.walk(directory):
        for filename in file:
            print("Import:" + filename)
            data = {}
            if root != directory:
                # Импортировать дашборд из текущей подпапке в соответствующию папку в графане
                folder_name = os.path.split(root)[1]
                folder_id = get_folder_id(folder_name, url, headers)
                if folder_id is not None:
                    data['folderId'] = folder_id
                else:
                    print("Сould not find dashboard folder. Dashboard will be imported into general folder.")
            dash = open(os.path.join(root, filename), "r").read()
            data["dashboard"] = json.loads(dash)
            data["overwrite"] = True
            data = json.dumps(data)
            response = requests.post(url + '/api/dashboards/db', data=data, headers=headers)
            if not response.ok:
                print("Import error: " + response.text + "\n\n")
                continue
            if sys.version_info[0] < 3:
                print(filename.decode('utf-8') + "\n" + response.text + "\n\n")
            else:
                print(filename + "\n" + response.text + "\n\n")


def get_folder_id(folder_name, url, headers):
    # Получить все папки
    response = requests.get(url + '/api/folders', headers=headers)
    if not response.ok:
        return None
    folders = response.json()
    for f in folders:
        if f['title'] == folder_name:
            return f['id']

    # Создать папку, если не нашли по названию
    data = {"title": folder_name}
    data = json.dumps(data)
    response = requests.post(url + '/api/folders', data=data, headers=headers)
    if response.status_code == 200:
        return response.json()['id']
    return None


if __name__ == '__main__':
    main(sys.argv[1:])
