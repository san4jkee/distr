#!/bin/bash

docker build . --tag grafana:1.0