# -*- coding: utf-8 -*-
#!/usr/bin/env python

import json
import requests
import os
import sys


def main(argv):
    tags = ['Alerts', 'Detail', 'Examples', 'Hardware', 'DirectumRX', 'Statistic', 'Smart search']
    url = "http://admin:1Qwerty@127.0.0.1"
    if len(argv) > 0:
        url = argv[0]
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    for tag in tags:
        headers["tag"] = tag
        # Получить все дашборды по заданным фильтрам
        response = requests.get('%s/api/search?query=&' % (url,), params=headers)
        if not response.ok:
            continue
        dashboards = response.json()
        for d in dashboards:
            folder_title = ''
            if d['title'].startswith('_'):
                continue
            # Получить дашборд по значению uri
            response = requests.get('%s/api/dashboards/%s' % (url, d['uri']), params=headers)
            if not response.ok:
                continue

            # Вытащить название папки, в которой лежит дашборд
            meta = response.json()['meta']
            if 'folderTitle' in meta:
                folder_title = meta['folderTitle']

            # Вытащить json дашборда
            data = response.json()['dashboard']
            directory = os.path.join(os.path.abspath(os.curdir), 'dashboards', folder_title)

            # Очистить параметры привязанный к конкретной серверу графаны
            data['id'] = None
            data['version'] = None

            # Получить имя дашборда
            dash = json.dumps(data, sort_keys=True, indent=4, separators=(',', ': '))
            name = data['title'].replace(' ', '_').replace('/', '_').replace(':', '').replace('[', '').replace(']', '')

            # Экспортировать дашборд
            if not os.path.exists(directory):
                os.makedirs(directory)
            tmp = open(os.path.join(directory, name + '.json'), 'w+')
            tmp.write(dash)
            tmp.write('\n')
            tmp.close()
            print(name + "\t exported")


if __name__ == '__main__':
    main(sys.argv[1:])
